#include <bits/stdc++.h>
using namespace std;


typedef struct node {
    int data;
    int height;
    struct node* left;
    struct node* right;

} Node;

// helper function to compute height of tree rooted at root

int height(Node* root){
    if(root == NULL){
        return 0;
    }
    return root->height;
}
int balanceFactor(Node* root){
    if(root == NULL){
        return 0;
    }
    int balance_factor = height(root->left) - height(root->right);
    return balance_factor;
}

Node* rightRotate(Node* y){
    Node* x = y->left;
    Node* T2 = x->right;

    //rotate now

    x->right = y;
    y->left = T2;

    // update heights

    y->height = 1 + max(height(y->left) , height(y->right));
    x->height = 1 + max(height(x->left) , height(x->right));
    
    return x;
}

Node* leftRotate(Node* x){
    Node* y = x->right;
    Node* T2 = y->left;

    //rotate now
    y->left = x;
    x->right = T2;
    
    // update heights

        x->height = 1 + max(height(x->left) , height(x->right));
    y->height = 1 + max(height(y->left) , height(y->right));

    

    return y;
}
// search function returns pointer to node if found else NULL

Node* searchNode(Node* root, int key){
    if(root == NULL){
        return NULL;
    }

    if(key == root->data){
        return root;
    }else if(key < root->data){
        return searchNode(root->left,key);
    }else{
        return searchNode(root->right,key);
    }


    return NULL;


    
}


Node* minimumValueNode(Node* root){
    Node* curr = root;
    while(curr != NULL && curr->left != NULL){
        curr = curr->left;
    }
    return curr;
}


// function to insert a node in the AVL tree

Node* insertNode(Node* root, int key){
    if(root == NULL){
        
        Node* newnode = (Node*)malloc(sizeof(struct node));
        newnode->data = key;
        newnode->left = NULL;
        newnode->right = NULL;
        newnode->height=1;
        return newnode;
    }

    if(key < root->data){
        root->left = insertNode(root->left,key);
    }else if(key > root->data){
        root->right = insertNode(root->right ,key);

    }else{
        // duplicate found so no insertion
        
        return root;
    }

    root->height = 1 + max(height(root->left),height(root->right));


    int balance_factor = balanceFactor(root);

    // left left

    if(balance_factor > 1 && key < root->left->data){
        return rightRotate(root);
    }

    // right right

    if(balance_factor < -1 && key > root->right->data){
        return leftRotate(root);
    }

    // left right

    if(balance_factor > 1 && key > root->left->data){
        root->left = leftRotate(root->left);
        return rightRotate(root);
    }


    // right left

    if(balance_factor < -1 && key < root->right->data){
        root->right = rightRotate(root->right);
        return leftRotate(root);
    }




    return root;

}

// function to delete node from the AVL tree



Node* deleteNode(Node* root, int key){
    if(root == NULL){
        
        return root;
    }

    if(key < root->data){
        root->left = deleteNode(root->left,key);
    }else if(key > root->data){
        root->right = deleteNode(root->right,key);
    }else{

        // node found
        

        // node with only 1 child or no child

        if(!root->left || !root->right){
            Node* temp = NULL;
            if(root->left != NULL){
                temp = root->left;
            }else{
                temp = root->right;
            }

            if(temp == NULL){
                // no child
                free(root);
                root = NULL;
            }else{
                // 1 child
                Node* toDelete = root;
root = temp;
free(toDelete);

                
            }


            
        }else{
            // for node with 2 childen get inorder successor

            Node* temp = minimumValueNode(root->right);
            root->data = temp->data;
            root->right = deleteNode(root->right,temp->data);
           
        }





    }

    if(root == NULL){
        return root;
    }


    root->height = 1 + max(height(root->left),height(root->right));

    // now balance the node
    int balance_factor = balanceFactor(root);

    // left left

    if(balance_factor > 1 && balanceFactor(root->left) >= 0){
        
        return rightRotate(root);
    }

    // right right

    if(balance_factor < -1 && balanceFactor(root->right) <= 0){
        
        return leftRotate(root);
    }

    // left right

    if(balance_factor > 1 && balanceFactor(root->left) < 0){
        
        root->left = leftRotate(root->left);
        return rightRotate(root);
    }

    //right left

    if(balance_factor < -1 && balanceFactor(root->right) >0){
        
        root->right = rightRotate(root->right);
        return leftRotate(root);
    }





    return root;
}

// level order traversal printing

void printLevelOrderTraversal(Node* root){
    if(root == NULL){
        return;
    }

    queue<Node*> q;
    q.push(root);

    while(!q.empty()){
        int size = q.size();
        for(int i=0;i<size;i++){

            Node* curr = q.front();
            q.pop();
            if(i>0){
                cout << " ";
            }

            cout << curr->data;
            if(curr->left != NULL){
                q.push(curr->left);
            }
            if(curr->right){
                q.push(curr->right);
            }
        

        }

        cout << "\n";
    }
}




int main(){

    int n;
    cin >> n;
    Node* root = NULL;
    for(int i=0;i<n;i++){
        int x;
        cin >> x;
        
        root = insertNode(root,x);

    }

    int type;
   


    while(cin >> type){

        

        if(type == 1){
            // search node
            int key;
            cin >> key;
            Node* result = searchNode(root,key);
            if(result != NULL){
                cout << key << " present\n";

            }else{
                cout << key << " not present\n";
            }
        }else if(type == 2){
            // insert node

            int key;
            cin >> key;
            

            Node* duplicate = searchNode(root,key);
            if(duplicate != NULL){
                cout << key << " already present. So no need to insert.\n";

            }else{
                root = insertNode(root,key);
                cout << key << " inserted\n";
            }

          



        }else if(type == 3){
            // delete node;
            int key;
            cin >> key;
            Node* key_present = searchNode(root,key);
            if(key_present == NULL){
                cout << key << " not present. So it can not be deleted\n";
                
            }else{
                root = deleteNode(root,key);
                cout << key << " deleted\n";
                
            }
        }else if(type == 4){
            printLevelOrderTraversal(root);
        }


    }


    return 0;
}