#include<bits/stdc++.h>
using namespace std;

// this class is implementation of main bloom filyer


class BloomFilter{

    public:

    int M;
    int K;
    vector<bool> bits;
    vector<unsigned int> hash_seeds;

    // construct bloom filter with m = size of bit array , k = number of hash functions

    BloomFilter(int m,int k): M(m), K(k), bits(m, false){
        mt19937 gen(random_device{}());
        uniform_int_distribution<unsigned int> dis(1, 0xFFFFFFFF);
        for(int i=0;i<k;i++){
            hash_seeds.push_back(dis(gen));
        }

    }

    // generate k hash values for given item

    vector<int> get_hashes(int item){
        vector<int> hashes;

        unsigned int base = hash<int>{}(item);
        // generating k different hashes using linear probing

        for(int i=0;i<K;i++){
            unsigned int probe = (base + i*31)%M;
            hashes.push_back((int)probe);

        }




        return hashes;
    }

    // insert an item into bloom filter

    void insert(int item){
        for(int hash_value: get_hashes(item)){
            bits[hash_value] = true;
        }
    }

    // checks if item is in the set (not accurate though)

    bool lookup(int item){
        for(int hash_value: get_hashes(item)){
            if(!bits[hash_value]){
                return false;
            }
        }

        return true;
    }





};

// load first max_n unique items from dataset file

void load_dataset(string& file_name , set<int>& dataset, int max_n){

    ifstream file(file_name);
    if(!file.is_open()){
                cout << "Error: Could not open query file " << file_name << endl;
        exit(1);
    }

    string line;
    while(getline(file,line)){
        stringstream ss(line);
        int item;
        while(ss >> item){
            if(dataset.size() < max_n){
                dataset.insert(item);
            }else{
                return;
            }
        }
    }

}

// load all items from query file into a vector

void load_queries(string& file_name, vector<int>& queries){

    ifstream file(file_name);
    if(!file.is_open()){
        cout << "Error: Could not open query file " << file_name << endl;
        exit(1);
    }

    string line;

    while(getline(file,line)){
        stringstream ss(line);
        int item;
        while(ss >> item){
            queries.push_back(item);
        }
    }


}

// this helper fucntion helps us in printing a good confusion matrix with formatting

void print_confusion_matrix(int tp, int fn,int fp, int tn){

    cout << "\nConfusion Matrix: \n";
    cout << "                   Predicted Positive      Predicted Negative\n";
    cout << "Actual Positive    " << tp << " (TP)                " << fn << " (FN)\n";
    cout << "Actual Negative    " << fp << " (FP)                " << tn << " (TN)\n";

}


int main(){

    vector<int> m_values = {2000,3000,4000};
    int n = 800;

    string dataset_file = "dataset.txt";
    string query_positive_file = "query_positive.txt";
    string query_negative_file = "query_negative.txt";

    // load all data

    set<int> dataset;
    vector<int> query_positive;
    vector<int> query_negative;

    cout << "Loading dataset...." << endl;

    load_dataset(dataset_file,dataset,n);

    cout << "Loaded " << dataset.size() << " unique items from " << dataset_file << endl;

    cout << "Loading positive queries.... " << endl;
    load_queries(query_positive_file,query_positive);
    cout << "Loaded " << query_positive.size() << " positive queries" << endl;


    cout << "Loading negative queries.... " << endl;
    load_queries(query_negative_file,query_negative);
    cout << "Loaded " << query_negative.size() << " negaive queries" << endl;

    for(int m: m_values){
        // calculate optimal k

        double double_k = ((double)m/n)* log(2);
        int k = (int)(round(double_k));

        if(k==0){
            k=1;
        }

        cout << "Testing with m = " << m << ", n = " << n << endl;
        cout << "Calculated optimal value of k = " << k << endl;

        // create filter

        BloomFilter bf(m,k);

        for(int item: dataset){
            bf.insert(item);
        }

        int tp=0,fp=0,tn=0,fn=0;
        for(int item:query_positive){
            if(bf.lookup(item)){
                tp++;
            }else{
                fn++;
            }
        }

        for(int item: query_negative){
            if(bf.lookup(item)){
                fp++;
            }else{
                tn++;
            }
        }

        print_confusion_matrix(tp,fn,fp,tn);


    }



    


    return 0;
}