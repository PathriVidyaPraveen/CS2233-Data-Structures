To run the program:

g++ problem.cpp -o problem && ./problem

Keep the file names as dataset.txt , query_positive.txt , query_negative.txt inside the same working directory
