// problem 1

#include <bits/stdc++.h>
using namespace std;

// node of a linked list with integer data stored in val and pointer to next node

typedef struct Node {
    int val;
    struct Node* next;
} Node;

// function to create a new node by allocating memory

Node* createNode(int val){
    Node* new_node = (Node*)malloc(sizeof(new_node));
    new_node->val = val;
    new_node->next = NULL;
    return new_node;
}
// two linked lists (sorted) that needs to be merged
Node* list1 = NULL;
Node* list2 = NULL;

// insertion of an element or node at the end of linked list

void insert(Node** head , int val){
    Node* node_to_be_inserted = createNode(val);
    if((*head) == NULL){
        (*head) = node_to_be_inserted;
        return;
    }

    Node* curr = *head;
    while(curr->next != NULL){
        curr = curr->next;
    }
    curr->next = node_to_be_inserted;
    return;

}

// function to print all the elements of the linked list
void print(Node* head){
    Node* curr = head;
    while(curr != NULL){
        cout << curr->val << " ";
        curr = curr->next;
    }
    cout << endl;
}

// function to merge both the sorted linked lists into a final sorted linked list

Node* merge(Node* a , Node* b){
    if(a == NULL){
        return b;
    }
    if(b == NULL){
        return a;
    }

    Node head ;
    Node* tail_ptr = &head;

    Node* curr1 = a;
    Node* curr2 = b;
    Node* prev = NULL;
    int flag = 0;
    
    // while(curr2 != NULL){
    //     if(curr2->val > curr1->val){
    //         if(curr1->next == NULL){
    //             curr1->next = curr2;
    //             flag++;
    //             break;
    //         }

    //         if(curr1->next->val < curr2->val){
    //             curr1 = curr1->next;
    //         }else{
    //             Node* temp = curr1->next;
    //             curr1->next = curr2;
    //             curr1 = temp;
    //         }
    //         flag++;


    //         // while((curr1->val <= curr2->val) && curr1 != NULL){
    //         //     prev = curr1;
    //         //     curr1 = curr1->next;
    //         // }

    //         // Node* temp = prev->next;
    //         // prev->next = curr2;
    //         // curr2->next = temp;
    //         // curr1 = temp;
            
    //     }else{
            
    //         Node* temp = curr2->next;
    //         curr2->next = curr1;
    //         if(flag == 0){
    //             a = curr2;
    //         }
    //         curr2 = temp;

            
    //         flag++;

    //     }
    // }


    // return a;

    while(a != NULL && b != NULL){
        if(a->val < b->val){
            tail_ptr->next = a;
            a = a->next;
        }else{
            tail_ptr->next = b;
            b = b->next;
        }
        tail_ptr = tail_ptr->next;
    }

    if(a != NULL){
        tail_ptr->next = a;
    }else{
        tail_ptr->next = b;
    }

    Node* final_list = head.next;
    return final_list;

    


}

int main(){

    // take user inputs and store them in 2 linked lists
    int n1;
    cin >> n1;
    int x;
    for(int i=0;i<n1;i++){
        cin >> x;
        insert(&list1,x);
    }
    int n2;
    cin >> n2;
    for(int i=0;i<n2;i++){
        cin >> x;
        insert(&list2,x);
    }

    // merge into final sorted linked list and print it

    Node* final_list = merge(list1,list2);
    print(final_list);

    return 0;
}

