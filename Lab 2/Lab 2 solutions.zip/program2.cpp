// problem 2

#include <bits/stdc++.h>
using namespace std;

// node of a linked list with integer data stored in val and pointer to next node
typedef struct Node {
    int val;
    struct Node* next;
} Node;

// function to create a new node by allocating memory
Node* createNode(int val){
    Node* new_node = (Node*)malloc(sizeof(new_node));
    new_node->val = val;
    new_node->next = NULL;
    return new_node;
}
// linked list that needs to be reversed
Node* linked_list = NULL;

// function to insert a new node at the end of the linked list
void insert(Node** head , int val){
    Node* node_to_be_inserted = createNode(val);
    if((*head) == NULL){
        (*head) = node_to_be_inserted;
        return;
    }

    Node* curr = *head;
    while(curr->next != NULL){
        curr = curr->next;
    }
    curr->next = node_to_be_inserted;
    return;

}

// function helper to print the elements of the linked list
void print(Node* head){
    Node* curr = head;
    while(curr != NULL){
        cout << curr->val << " ";
        curr = curr->next;
    }
    cout << endl;
}

// function to reverse the linked list **
void reverse(Node** head){
    Node* curr = *head;
    Node* prev = NULL;
    while(curr != NULL){
        Node* next = curr->next;
        curr->next = prev;
        prev = curr;
        curr = next;
    }
    *head = prev;
    

}


int main(){

    // take inputs from user and stores in linked list

    int n;
    cin >> n;

    for(int i=0;i<n;i++){
        int x;
        cin >> x;
        insert(&linked_list,x);
    }
    // reverses the linked list and prints the element
    reverse(&linked_list);

    print(linked_list);


    return 0;
}