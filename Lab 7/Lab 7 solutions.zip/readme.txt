Instruction to run the program :

g++ problem.cpp -o problem && ./problem


Input format:

All the numbers that needs to be sorted must be given as space separated integers

Example input:

57 64 72 85 93 58 69 76 88 94 61 79 66 82 97

Example output:

57 58 61 64 66 69 72 76 79 82 85 88 93 94 97


