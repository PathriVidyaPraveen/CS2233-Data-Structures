#include<bits/stdc++.h>
using namespace std;

// this function helps in maintaining the min heap property

void heapify(vector<int>& a, int n , int i){
    int smallest = i;
    int left = 2*i +1;
    int right = 2*(i+1);


    if(left < n && a[left] < a[smallest]){
        smallest = left;
    }


    if(right < n && a[right] < a[smallest]){
        smallest = right;
    }

    if(smallest != i){
        swap(a[i],a[smallest]);
        heapify(a,n,smallest);
    }


    return;


}


// remove smallest value and again heapify

void deleteMin(vector<int>& a, int &n){
    swap(a[0],a[n-1]);
    n--;
    heapify(a,n,0);
}




void heapSort(vector<int>& a){
int n = a.size();

    // build min heap

    for(int i=n/2-1;i>=0;i--){
        heapify(a,n,i);
    }

    int size = n;

    // applly delete min repeatedly

    while(size > 1){
        deleteMin(a,size);
    }

    // now we should reverse it for sorted sequence of ascending order

    for(int i=0;i<n/2;i++){
        swap(a[i],a[n-1-i]);
    }
}

int main(){

    //parse the input for getting all input elements to be sorted as numer of elements is not given in input

    

    vector<int> input;
    string line;

    getline(cin,line);

    stringstream ss(line);

    int x;
    while(ss >> x){
        input.push_back(x);
    }

    if(input.size() == 0){
        cout << "Empty input!" << endl;
        return 0;
    }


    heapSort(input);

    for(int i=0;i<input.size();i++){
        cout << input[i] << " ";
    }

    cout << endl;





    return 0;
}