#include<bits/stdc++.h>
using namespace std;

#define RED false
#define BLACK true


// node definition

typedef struct node {
    int data;
    struct node* left;
    struct node* right;
    struct node* parent;
    bool color;
    int black_depth;
} Node;


// preorder traversal of red black tree

void preorder(Node* root){
    if(root == NULL){
        return;
    }
    cout << root->data << "(" << (root->color == RED ? "R" : "B") << ") ";
    preorder(root->left);
    preorder(root->right);
}

// inorder traversal of red black tree

void inorder(Node* root){

    if(root == NULL){
        return;
    }
    inorder(root->left);
    cout << root->data << "(" << (root->color == RED ? "R" : "B") << ") ";
    inorder(root->right);

}

// helper function for creating a new node

Node* createNode(int data){
    Node* newnode = (Node*)malloc(sizeof(struct node));
    newnode->data = data;
    newnode->left = NULL;
    newnode->right = NULL;
    newnode->parent = NULL;
    newnode->color = RED;
    newnode->black_depth = 0;
    return newnode;

}

// function to search for an element in Red black tree


Node* search(Node* root, int key){
    if(root == NULL){
        cout << "Key: " << key << " not found!\n";
        return NULL;
    }
    if(key == root->data){
        cout << "Key: " << key << " found! Color: " << (root->color == RED ? "R" : "B") << "\n";
        return root;
    }else if(key < root->data){
        return search(root->left,key);
    }else{
        return search(root->right,key);
    }


    return NULL;

}

// rotation helper functions for insertion

void leftRotate(Node*& root, Node* x){
    Node* y = x->right;
    x->right = y->left;
    if(y->left != NULL){
        y->left->parent = x;
    }
    y->parent = x->parent;
    if(x->parent == NULL){
        root = y;
    }else if(x == x->parent->left){
        x->parent->left = y;
    }else{
        x->parent->right = y;
    }
    y->left = x;
    x->parent = y;
}



void rightRotate(Node*& root, Node* x) {
    Node *y = x->left;  


    x->left = y->right;


    if (y->right != NULL){
        y->right->parent = x;
}

    y->parent = x->parent;

    if(x->parent == NULL){
        root = y;
    }else if(x == x->parent->right){
        x ->parent->right = y;
    }else{
        x->parent->left = y;
    }




    y->right = x;
    x->parent = y;

}


// fix up function after insertion

void fixInsert(Node*& root, Node* z){


    while(z->parent!= NULL && z->parent->color == RED){
        Node* gp = z->parent->parent;
        if(z->parent == gp->left){
            Node* sp = gp->right;
            if(sp != NULL && sp->color == RED){
                z->parent->color = BLACK;
                sp->color = BLACK;
                gp->color = RED;
                z = gp;
            }else{
                if(z == z->parent->right){



                    z = z->parent; 

                    leftRotate(root,z);
                }
                z->parent->color = BLACK;
                gp->color = RED;


                rightRotate(root,gp);
            }
        }else{
            Node* sp = gp->left;
            if(sp != NULL && sp->color == RED){
                z->parent->color = BLACK;
                sp->color = BLACK;
                gp->color = RED;
                z = gp;
            }else{
                if(z == z->parent->left){
                    z = z->parent;
                    rightRotate(root,z);
                }

                z->parent->color = BLACK;
                gp->color = RED;
                leftRotate(root,gp);
            }


        }

    }

    root->color = BLACK;
}   



// insert function

void insert(Node*& root, int key){
    Node* newnode = createNode(key);
    Node* y = NULL;
    Node* x = root;



    while(x != NULL){
        y = x;
        if(key < x->data){
            x = x->left;
        }else if(key > x->data){
            x = x->right;
        }else{
            cout << "Key already exists!" << endl;
            free(newnode);
            return;
        }
    }

    newnode->parent = y;
    if(y == NULL){
        root = newnode;
    }else if(key < y->data){
        y->left = newnode;
    }else{
        y->right = newnode;
    }

    fixInsert(root,newnode);
    return;
}

// find minimum

Node* treeMinimum(Node* node){
    while(node->left != NULL){
        node = node->left;
    }
    return node;

}

// fix things after deletion

void fixDelete(Node*& root, Node* x,Node* x_parent){
      while(x != root && (x == NULL || x->color == BLACK)){
        if(x==NULL || x_parent==NULL){
            break;}
        if(x == x_parent->left){
            Node* w = x_parent->right;
            if(w==NULL){
                break;
            }
            if(w->color == RED){
                w->color = BLACK;
                x_parent->color = RED;
                leftRotate(root,x_parent);
                w = x_parent->right;
            }

            if((w->left == NULL || w->left->color == BLACK) && (w->right == NULL || w->right->color == BLACK)){
                w->color = RED;
                x = x_parent;
            }else{
                if(w->right == NULL || w->right->color == BLACK){
                    if(w->left != NULL){
                        w->left->color = BLACK;
                    }
                    w->color = RED;
                    rightRotate(root,w);
                    w = x_parent->right;
                }
                w->color = x_parent->color;
                x_parent->color = BLACK;
                if(w->right != NULL){
                    w->right->color = BLACK;
                }
                leftRotate(root,x_parent);
                x = root;
            }
        }else{
           Node* w= x_parent->left;
           if(w==NULL){
            break;
           }
           if(w->color == RED){
            w->color = BLACK;
            x_parent->color = RED;
            rightRotate(root,x_parent);
            w = x_parent->left;

            }
            
            if((w->right == NULL||w->right->color == BLACK) && (w->left == NULL ||w->left->color == BLACK)){
                w->color = RED;
                x = x_parent;
            }else{
                if(w->left == NULL || w->left->color == BLACK){
                    if(w->right != NULL){
                        w->right->color = BLACK;

                    }
                    w->color = RED;
                    leftRotate(root,w);
                    w =x_parent->left;
                }
                w->color= x_parent->color;
                x_parent->color = BLACK;
                if(w->left!=NULL){
                    w->left->color = BLACK;
                }
                rightRotate(root,x_parent);
                x = root;
            }


        }
      }


if(x != NULL){
    x->color=BLACK;
}

return;

}

// just a small helper for delete to search without error message(which I wrote directly in function itself previously)


Node* searchWithoutMessage(Node* root, int key){
    if(root == NULL){
        // cout << "Key: " << key << " not found!\n";
        return NULL;
    }
    if(key == root->data){
        // cout << "Key: " << key << " found!\n";
        return root;
    }else if(key < root->data){
        return searchWithoutMessage(root->left,key);
    }else{
        return searchWithoutMessage(root->right,key);
    }


    return NULL;

}

void deleteRBT(Node*& root, int key){
       Node* z = searchWithoutMessage(root,key);
       if(z == NULL){
        cout << "Key : " << key << " does not exist!\n";
        return;
       }


       Node* y =z;
       Node* x= NULL;
       Node* x_parent = NULL;
       bool y_initial_color = y->color;


       if(z->left == NULL){
        x = z->right;
        x_parent = z->parent;
        if(x!= NULL){
            x->parent = z->parent;
        }
        if(z->parent == NULL){
            root= x;

        }else if(z == z->parent->left){
            z->parent->left = x;
        }else{
            z->parent->right = x;
        }

        free(z);

       }else if(z->right == NULL){
         x = z->left;
         x_parent = z->parent;
         if(x!= NULL){
            x->parent = z->parent;
         }
         if(z->parent == NULL){
            root = x;
         }else if(z == z->parent->left){
            z->parent->left = x;
         }else{
            z->parent->right = x;
         }


         free(z);



       }else{
        y = treeMinimum(z->right);
        y_initial_color = y->color;
        x = y->right;

        if(y->parent == z){
            x_parent = y;
        }else{
              x_parent = y->parent;
        }
        if(y->parent == z){
            if(x!= NULL){
                x->parent = y;
            }
        }else{
            if(x != NULL){
                x->parent = y->parent;
            }
            y->parent->left = x;
            y->right = z->right;
            z->right->parent = y;
        }
        if(z->parent == NULL){
            root = y;
        }else if(z == z->parent->left){
            z->parent->left = y;
        }else{
            z->parent->right = y;
        }

        y->parent = z->parent;
        y->left = z->left;
        z->left->parent = y;
        y->color = z->color;
        free(z);



}

        

        if(y_initial_color == BLACK){
            fixDelete(root,x,x_parent);

        }


        cout << "Key : " << key << " deleted!\n";

return;
}


int main(){

    int n;
    cin >> n;

    // root pointer of red black tree

    Node* root = NULL;

    vector<int> a(n);
    for(int i=0;i<n;i++){
        cin >> a[i];
        insert(root,a[i]);
    }


    cout << "Initial inorder traversal: " << endl;
    inorder(root);
    cout << endl;
    cout << "Initial preorder traversal: " << endl;
    preorder(root);
    cout << endl;
    int choice;


    while(true){


    cout << "Enter your choice: \n1 - Search for an element\n2 - Insert an element\n3 - Delete an element\n0 - Exit\n";

    cin >> choice;
    if(choice == 1){
        int e;
        cin >> e;
        Node* searched_ptr = search(root,e);
        
    }else if(choice == 2){
        int e;
        cin >> e;
        insert(root,e);
        cout << "Inorder traversal: \n";
        inorder(root);
        cout << endl;
        cout << "Preorder traversal: \n";
        preorder(root);
        cout << endl;
    }else if(choice == 3){
        int e;
        cin >> e;
        deleteRBT(root,e);
    }else if(choice == 0){
        break;
    }else{
        cout << "Invalid option! Please try again!" << endl;
    }




    }

    return 0;
}