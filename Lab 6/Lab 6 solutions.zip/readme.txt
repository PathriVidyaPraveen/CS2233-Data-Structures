Command to run the given program :
g++ problem.cpp -o problem && ./problem


Input:

The first integer will be n, the size of the array. This will be followed by the n space separated
elements of the array.


Output:

Print the inorder traversal, followed by the preorder traversal in the next line.
Then display the following prompt:
Enter your choice:
1 - Search for an element
2 - Insert an element
3 - Delete an element
0 - Exit
The program should keep showing this menu until the user enters 0. For every
action, take one integer input (the element to work with) and perform the
corresponding operation.



Given example test case in the problem statement:

17
9 8 5 4 99 78 31 34 89 90 21 23 45 77 88 112 32
Initial inorder traversal: 
4(R) 5(B) 8(B) 9(R) 21(B) 23(R) 31(B) 32(R) 34(B) 45(R) 77(B) 78(B) 88(R) 89(B) 90(R) 99(B) 112(R) 
Initial preorder traversal: 
31(B) 8(B) 5(B) 4(R) 21(B) 9(R) 23(R) 78(B) 45(R) 34(B) 32(R) 77(B) 90(R) 89(B) 88(R) 99(B) 112(R) 
Enter your choice: 
1 - Search for an element
2 - Insert an element
3 - Delete an element
0 - Exit
1
32
Key: 32 found! Color: R
Enter your choice: 
1 - Search for an element
2 - Insert an element
3 - Delete an element
0 - Exit
1
56
Key: 56 not found!
Enter your choice: 
1 - Search for an element
2 - Insert an element
3 - Delete an element
0 - Exit
1
90
Key: 90 found! Color: R
Enter your choice: 
1 - Search for an element
2 - Insert an element
3 - Delete an element
0 - Exit
2
132
Inorder traversal: 
4(R) 5(B) 8(B) 9(R) 21(B) 23(R) 31(B) 32(R) 34(B) 45(R) 77(B) 78(B) 88(R) 89(B) 90(R) 99(R) 112(B) 132(R) 
Preorder traversal: 
31(B) 8(B) 5(B) 4(R) 21(B) 9(R) 23(R) 78(B) 45(R) 34(B) 32(R) 77(B) 90(R) 89(B) 88(R) 112(B) 99(R) 132(R) 
Enter your choice: 
1 - Search for an element
2 - Insert an element
3 - Delete an element
0 - Exit
2
156
Inorder traversal: 
4(R) 5(B) 8(B) 9(R) 21(B) 23(R) 31(B) 32(R) 34(B) 45(B) 77(B) 78(R) 88(R) 89(B) 90(B) 99(B) 112(R) 132(B) 156(R) 
Preorder traversal: 
31(B) 8(B) 5(B) 4(R) 21(B) 9(R) 23(R) 78(R) 45(B) 34(B) 32(R) 77(B) 90(B) 89(B) 88(R) 112(R) 99(B) 132(B) 156(R) 
Enter your choice: 
1 - Search for an element
2 - Insert an element
3 - Delete an element
0 - Exit
2
11
Inorder traversal: 
4(R) 5(B) 8(B) 9(B) 11(R) 21(R) 23(B) 31(B) 32(R) 34(B) 45(B) 77(B) 78(R) 88(R) 89(B) 90(B) 99(B) 112(R) 132(B) 156(R) 
Preorder traversal: 
31(B) 8(B) 5(B) 4(R) 21(R) 9(B) 11(R) 23(B) 78(R) 45(B) 34(B) 32(R) 77(B) 90(B) 89(B) 88(R) 112(R) 99(B) 132(B) 156(R) 
Enter your choice: 
1 - Search for an element
2 - Insert an element
3 - Delete an element
0 - Exit
2
7
Inorder traversal: 
4(R) 5(B) 7(R) 8(B) 9(B) 11(R) 21(R) 23(B) 31(B) 32(R) 34(B) 45(B) 77(B) 78(R) 88(R) 89(B) 90(B) 99(B) 112(R) 132(B) 156(R) 
Preorder traversal: 
31(B) 8(B) 5(B) 4(R) 7(R) 21(R) 9(B) 11(R) 23(B) 78(R) 45(B) 34(B) 32(R) 77(B) 90(B) 89(B) 88(R) 112(R) 99(B) 132(B) 156(R) 
Enter your choice: 
1 - Search for an element
2 - Insert an element
3 - Delete an element
0 - Exit
3
332
Key : 332 does not exist!
Enter your choice: 
1 - Search for an element
2 - Insert an element
3 - Delete an element
0 - Exit
3
51
Key : 51 does not exist!
Enter your choice: 
1 - Search for an element
2 - Insert an element
3 - Delete an element
0 - Exit
3
71
Key : 71 does not exist!
Enter your choice: 
1 - Search for an element
2 - Insert an element
3 - Delete an element
0 - Exit
3
67
Key : 67 does not exist!
Enter your choice: 
1 - Search for an element
2 - Insert an element
3 - Delete an element
0 - Exit
0