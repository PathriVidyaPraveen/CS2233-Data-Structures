#include<bits/stdc++.h>
using namespace std;

// tree node definition

typedef struct Node{
    int data;
    struct Node* left;
    struct Node* right;

} Node;

// helper fcuntion to create a new node from the given integer data

Node* createNode(int data){
    Node* newnode = (Node *)malloc(sizeof(struct Node));
    newnode->data = data;
    newnode->left = NULL;
    newnode->right = NULL;
    return newnode;
}

// function to search a given key in the binary search tree

Node* search(Node* root , int key){
    if(root == NULL){
        cout << "Key " << key << " not found!" << endl;
        return NULL;
    }
    if(root->data == key){
        cout << "Key " << key << " found!" << endl;
        return root;
    }else if(key < root->data){
        return search(root->left,key);
    }else{
        return search(root->right,key);
    }
}


// function to insert a new node with data as key in the appropriate position in BST

Node* insert(Node* root , int key){
    Node* newnode = createNode(key);
    if(root == NULL){
        root = newnode;
        return root;
    }
    if(key < root->data){
        root->left = insert(root->left,key);
        return root;
    }else if(key > root->data){
        root->right = insert(root->right,key);
        return root;
    }else{
        cout << "Node of this key already exists!" << endl;
        return root;
    }
}

// function to delete the given value containing node from the key 

Node* minValueNode(Node* node){
    Node* curr = node;
    while(curr->left != NULL){
        curr = curr->left;
    }
    return curr;


}

Node* deleteNode(Node* root,int key){
    
    if(root==NULL){
        return NULL;
    }
    if(key < root->data){
        root->left = deleteNode(root->left,key);
    }else if(key > root->data){
        root->right = deleteNode(root->right,key);
    }else{
        // found the node
        if(root->left==NULL){
            Node* temp = root->right;
            free(root);
            return temp;
        }
        if(root->right == NULL){
            Node* temp = root->left;
            free(root);
            return temp;
        }
        // two children present so find inorder successor
        Node* succ = minValueNode(root->right);
        root->data = succ->data;
        root->right = deleteNode(root->right,succ->data);
    }
    return root;
    
}

// helper function to find the successor of given node

// Node* searchAncestor(Node* root,int key){
//     Node* ancestor = NULL;
//     Node* curr = root;
//     while(curr != NULL && curr->data == key){
//         if(key < curr->data){
//             ancestor = curr;
//             curr = curr->left;
//         }else if(key > curr->data){
//             curr = curr->right;
//         }
//     }
//     return ancestor;

// }

// function to find the successor of a given node in BST



Node* successor(Node* root , int key){
    Node* keynode = search(root,key);
    if(keynode == NULL){
        return NULL;
    }
    // if right child exists for node key return that right child
    if(keynode->right != NULL){
        return minValueNode(keynode->right);
    }
    // if key is present at the most right leaf then there is no successor to it
    Node* curr = root;
    Node* successor = NULL;
    while(curr != NULL){
        if(key < curr->data){
            successor = curr;
            curr = curr->left;
        }else if(key > curr->data){
            curr = curr->right;
        }else{
            break;
        }

    }
    if(successor == NULL){
        cout << "No successor found! " << endl;
        
    }


    return successor;
   
}


// level order traversal of BST function
#define QUEUE_SIZE 1000000

void levelOrder(Node* root){
    if(root == NULL){
        cout << endl;
        return;
    }

    Node* q[QUEUE_SIZE];
    int front = 0 , rear = 0;
    q[rear++] = root;
    while(front < rear){
        Node* node = q[front++];
        cout << node->data << " ";
        if(node->left != NULL){
            q[rear++] = node->left;
        }
        if(node->right != NULL){
            q[rear++] = node->right;
        }
    }
    cout << endl;

}



// main function to implement the code for given values of tree nodes

int main(){

    int n;
    cin >> n;


    Node* root = NULL;

    for(int i=0;i<n;i++){
        int x;
        cin >> x;
        root = insert(root,x);
    }

    // print initial tree
    
    levelOrder(root);

    while(true){
        cout << "Enter your choice:" << endl;
        cout << "1 - Search for an element" << endl;
        cout << "2 - Insert an element" << endl;
        cout << "3 - Find the successor of an element" << endl;
        cout << "4 - Delete an element" << endl;
        cout << "0 - Exit" << endl;

        int choice;
        cin >> choice;
        if(choice == 0){
            break;
        }
        int key;
        cin >> key;

        if(choice == 1){
            search(root,key);
        }else if(choice == 2){
            root = insert(root,key);
            levelOrder(root);
        }else if(choice==3){
            Node* succ = successor(root,key);
            if(succ != NULL){
                cout << "Successor of " << key << " is " << succ->data << endl;
            }

        }else if(choice == 4){
            root = deleteNode(root,key);
            levelOrder(root);
        }
    }

    





    return 0;
}