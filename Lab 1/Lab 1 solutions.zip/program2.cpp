// problem 2

#include <bits/stdc++.h>
using namespace std;


// maximum stack size have been set to 10^7

#define MAX_STACK_SIZE 10000000 
int stack1[MAX_STACK_SIZE];
int stack2[MAX_STACK_SIZE];

int top1 = -1;
int top2 = -1;


void push1(int item){
    if(top1 < MAX_STACK_SIZE-1){
    stack1[++top1] = item;
    
    }
    else{
        cout << "Stack 1 overflow!\n";
    }
}

void push2(int item){
    if(top2 < MAX_STACK_SIZE-1){
    stack2[++top2] = item;
    
    }
    else{
        cout << "Stack 2 overflow!\n";
    }
}



int pop1(){
    if(top1 == -1){
        cout << "Queue is empty\n";
        return -1;
    }else{
        int popped = stack1[top1];
        top1--;
        return popped;
    }

    return -1;
}

int pop2(){
    if(top2 == -1){
        cout << "Queue is empty\n";
        return -1;
    }else{
        int popped = stack2[top2];
        top2--;
        return popped;
    }

    return -1;
}

// queue operations

void print(){
    for(int i=0;i<=top1;i++){
        cout << stack1[i] << " ";
    }
    cout << endl;
}


void enqueue(int x){

    push1(x);
    // cout << "Queue: " ;
    // print();

}

void transfer_elements(){
    while(top1 >= 0){
        int item = pop1();
        push2(item);
        
        
    }
}

void dequeue(){

    transfer_elements();
    int item = pop2();
    if(item != -1){
    cout << "Dequeued : " << item << endl;
    }
    while(top2 >= 0){
        int x = pop2();
        push1(x);

    }

}





int main(){
    while(true){
        int op ;
        cin >> op;
        if(op == 1){
            int item;
            cin >> item;
            enqueue(item);
        }else if(op == 2){
            dequeue();
        }else if(op == 3){
            break;
        }else {
            cout << "Invalid operation!\n";
            break;
        }
    }


    return 0;
}

