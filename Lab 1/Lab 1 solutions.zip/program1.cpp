// problem 1

#include <bits/stdc++.h>
using namespace std;

// typedef struct Queue{
//     int *arr;
//     int size;
//     int front;
//     int rear;
// }Queue;

// Queue *createQueue(int n){
    
//     // Queue queue = (Queue)malloc(sizeof(Queue *));
//     (Queue *) q = (Queue *)malloc(sizeof(Queue));


// }

#define MAX_SIZE 10000000
int q[MAX_SIZE];
int front = 0;
int rear = 0;
int q_size = 0;


int s[MAX_SIZE];
int top = -1;

void push(int item){
    if(top < MAX_SIZE-1){
        s[++top] = item;
        

    }else{
        cout << "Stack overflow\n";
        
    }
    return;
}

int pop(){
    if(top != -1){
        int removed = s[top];
        top--;
        
        return removed;
        
    }else{
        cout << "Stack underflow!\n";
        return -1;
    }
}

void enqueue(int x){
    if(q_size < MAX_SIZE){
        q[rear] = x;
        rear = (rear+1)%MAX_SIZE;
        q_size++;
    }
    else{
        cout << "Queue overflow\n";
    }
    return;
}

int dequeue(){
    if(q_size > 0){

        int item = q[front];
        front = (front+1)%MAX_SIZE;
        q_size--;
        return item;

    }else{
        cout << "Queue underflow!\n";
        return -1;
    }
}

void print(){
    int i=front;
    while(i < (rear+1)%MAX_SIZE - 1){
        cout << q[i] << " ";
        i = (i+1)%MAX_SIZE;
    }
    cout << endl;
}


int main(){
    int n;
    cin >> n; 

    for(int i=0;i<n;i++){
        int x;
        cin >> x;
        enqueue(x);
    }

    // print();


    int k;
    cin >> k;
    if(k > n){
        cout << "Invalid!\n";
        return 0;
    }

    for(int i=0;i<k;i++){
        int item = dequeue();
        push(item);
    }
    // print();

    if(n == k){
        for(int i=0;i<n;i++){
            enqueue(pop());
        }
        
    }else{

    int a[n-k];

    for(int i=0;i<n-k;i++){
        a[i] = dequeue();
    }
    for(int i=0;i<k;i++){
        enqueue(pop());
    }
    for(int i=0;i<n-k;i++){
        enqueue(a[i]);
    }


    }

    print();
    

}

